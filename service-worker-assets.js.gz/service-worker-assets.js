﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+\/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-9y4moGfZ0t5Rp1NHM3TG6Ke1fFjyv+XNYqZIR6NlOxk=",
      "url": "404.html"
    },
    {
      "hash": "sha256-SO\/fuIIWUxoIu1OABrOpK5n\/AvzxJcg+0H3PT1eutAE=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-YLGeXaapI0\/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-hrA6L8y6lIwkLQGsIGKfwONAxuJ0Ulj+8ZrGv0YuRME=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-UxKwWG\/BsQFaRH\/KCKRRleQgjhCuaugI8i6ClBoMQlE=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-s\/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-4+2XhXOzKpLLnnYxMbvezrf40zeMlls6\/FLo6jo0IGc=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9y4moGfZ0t5Rp1NHM3TG6Ke1fFjyv+XNYqZIR6NlOxk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-dQN4c4gRSKpCmsjFLx+iWQGOFmmwXvI+xBkA5CiWE8k=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-OEDZp6noMH3AdT8qd0zd7ZXzy2CsPQ+CZeQnYmRoVWo=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-YXYNlLeMqRPFVpY2KSDhleLkNk35d9KvzzwwKAoiftc=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-I5VC+YUYUBudBWJmDVJBNKOtxIJtlwTf75bz+XYls74=",
      "url": "_framework\/dotnet.5.0.6.js"
    },
    {
      "hash": "sha256-YlXgtVZYNLHmrx2ohJvDjoAVtEQrihGqAXbSYc80cMg=",
      "url": "SpaInspector.styles.css"
    },
    {
      "hash": "sha256-s4x4EfQJ2ajWanXL4AVMs7Clmj11NPWHRWeGpSroe3E=",
      "url": "_content\/Plotly.Blazor\/plotly-interop.js"
    },
    {
      "hash": "sha256-rwZnfP8qy8SDqYsQq8UYTz1LSicLLDpqHkmMVP9qM18=",
      "url": "_content\/Plotly.Blazor\/plotly-latest.min.js"
    },
    {
      "hash": "sha256-XTsavbgRpIguDhBkxCqIKRHeyoXJtZY1nV3C1oKIfSg=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-NfcbhMZ5d\/Rm2+xxcWSoQHAjREzkjfIK3DqCOLC2TCw=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-rLiw7Qj07nPhjySwrZ\/FcIq0VzTjBg8rgS5vi5+gGLE=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-bZZ69\/58+BnN9G33FpTd2iXAdfgLbBnDUiiKxfaZ7IU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7mxFRRlriJzO95ZBz4cmDSFADogdaoDy8MxzQoNtwaU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-cwzKuqTaJjYc5QXknt6NaBt\/MWSt9DYHfmu0I\/CV2mc=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-3M5HLhwr6aFByq3YSnp+yMWxEsGMOyR0FUtURRzgpPw=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-8L6pzpycBrKxgs\/3WsBVoR\/7NenUcL+e0i19DvlMog8=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-TpIA498zSsaZAjS+42XzHSmeWdSuY4\/\/ydfZQGlz1O8=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-TSzg6qsgsxZ162vc0deudnTvJ85ORFBpjYjqJ7LqFSA=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-g1C9Fnh++M4k1mLduCz2yUnf\/70tTCbdZ\/s6bDjsmZM=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-32yXMbcCMbfUq7vtlIPput8uO7SZK8E9m3V8EXMScBc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-qVfBFmJvf7A8AunXzjL0o5M1BhwlNrsL3TQ38pfJuCQ=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-uJLUw9XzHuJvg24MjIpf\/cAxCh1nXtCXBwROpjxObjo=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-\/u3OV3CHSnHOGs9hUHxOV2r6Be+flhjbl5QOWjJdhVk=",
      "url": "_framework\/Plotly.Blazor.dll"
    },
    {
      "hash": "sha256-qZYTUS+ga7CydtH54fYPbehFCvx3B49I74G8dxreTog=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-sRX22D6NPFrhfwL\/ou6ivsbnxOHNZCfUPcPiPJVqcHk=",
      "url": "_framework\/SpaInspectorReader.dll"
    },
    {
      "hash": "sha256-sTD6qKH2OBpa\/P7K+QWZZpGRMUlyIxQZj+B+31XiL78=",
      "url": "_framework\/SpaInspector.dll"
    },
    {
      "hash": "sha256-QY8ew4NHlrrbfcAmIPTWRLCPgbVhJogb3z2RY0w2AjU=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-T9nALQ1vYbcomS\/9WOg0Ztav+nE5MTBmwV3aJQY6q34=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-O1pGcRkIY9jCpKn6Bhq3n9L5qxr4KublMTi81XJxN6w=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-fCPW2ao2DGmJlxTxDOp1q1pKZK0EEKe8HToMRphMYFM=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-PsyDp5L9M4+y\/9oZd7PoziW8Vftfno42ZOdowJfO1aw=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-5F9PwREkKK\/BNBhOiMFqIS25yg86ojzQr1OCnJ3YMD8=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-DL5TvejOhqqJ\/hBJePF5g4Heko8r6uEIWqFd6oaa5lQ=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-G7xZLiMhfQqsJ7caCotSSsaesUsC4GyERgYo7GRo1Gg=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-TdmC\/2c\/KuucQ+pijDPN49YPgzos8AxBje1Jg642i8E=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-entM2ucQtWSxz\/7pA1\/\/h0njxQGawaMimhtwYOqPq7g=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-apk3y41wctR3I14wTFEGAMgJL14EkIaXLLzSeVgpOfA=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-6GXYZDdj6S\/qfjKmly+onzOkQqcIGNF+AMVJ29EvtjI=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-+KoM2\/u0qmrQ37qUv4qbWVCEa\/mKNopqhB3+VRlWK0U=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-7ok15J6vh5Q91MueNwa5hOJnpAJGpdNql19\/yf7xhsU=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-tglIL7DmTH778UZ6souQj3MMATAe4kWXsNJOHrgMwto=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-8P6y\/o6HIckX5rj8PNkNgjxh0OgxW3eFi9K7wliLfW0=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-67VurphS4qeMV8dnzw7qyG9ts9uSXUlCb3EAq\/AcKdM=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-fyb5d68lRCdh+yis\/FzNAyUXv0wKFL7k4pj9ZdZBCac=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-CYdWCHLF+HSUPNDgVqBlO\/IE0dRo\/V+sJpUCJcBYFeI=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-0BfXHINjHGmFxgdm\/ErhZNsCXpHeu+cSfeYD3eobiGs=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-b7Z69ZWVNRh6BfK7aoDHtexX7uwAcK6dHGFTR9ChUGk=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-OZlPh5gsrIrckIPDzAEjy\/24NdCs\/LubuWQwclLPHno=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "yUxZu3rX"
};
