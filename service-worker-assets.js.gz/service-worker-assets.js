﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-9y4moGfZ0t5Rp1NHM3TG6Ke1fFjyv+XNYqZIR6NlOxk=",
      "url": "404.html"
    },
    {
      "hash": "sha256-SO\/fuIIWUxoIu1OABrOpK5n\/AvzxJcg+0H3PT1eutAE=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-YLGeXaapI0\/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-hrA6L8y6lIwkLQGsIGKfwONAxuJ0Ulj+8ZrGv0YuRME=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-UxKwWG\/BsQFaRH\/KCKRRleQgjhCuaugI8i6ClBoMQlE=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-s\/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-4+2XhXOzKpLLnnYxMbvezrf40zeMlls6\/FLo6jo0IGc=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9y4moGfZ0t5Rp1NHM3TG6Ke1fFjyv+XNYqZIR6NlOxk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-dQN4c4gRSKpCmsjFLx+iWQGOFmmwXvI+xBkA5CiWE8k=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-nXByiCO4+RYyh+A88TSSZDwAJMF7M7Up\/h6dfAA19C8=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-qUhgve+80Xc4EIDgHhHFKd9isV5eO+3U0y8ydLADj64=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-SWZOE2EsCqc\/7dPgJrcFqUvVvdeJ9cipeZ2NFMC9v2s=",
      "url": "_framework\/dotnet.5.0.1.js"
    },
    {
      "hash": "sha256-YlXgtVZYNLHmrx2ohJvDjoAVtEQrihGqAXbSYc80cMg=",
      "url": "SpaInspector.styles.css"
    },
    {
      "hash": "sha256-s4x4EfQJ2ajWanXL4AVMs7Clmj11NPWHRWeGpSroe3E=",
      "url": "_content\/Plotly.Blazor\/plotly-interop.js"
    },
    {
      "hash": "sha256-i1J+Z0EtnwB\/gZSAMJQESV01TkaQ+0zvEwYtn3L6zXM=",
      "url": "_content\/Plotly.Blazor\/plotly-latest.min.js"
    },
    {
      "hash": "sha256-T0SPloiRYep8UbRrGSKqcMsSjvfRNMOzz7RCHlofxpU=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-T7p3HirvZEra+mEXB0HSOSH8K04rz\/b5O0ojRmDIoq4=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-jyPM6R2Q988oSbJyC3MxKsUmY3R\/G3DlinczzJQX1Sg=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-bZZ69\/58+BnN9G33FpTd2iXAdfgLbBnDUiiKxfaZ7IU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-7mxFRRlriJzO95ZBz4cmDSFADogdaoDy8MxzQoNtwaU=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-cwzKuqTaJjYc5QXknt6NaBt\/MWSt9DYHfmu0I\/CV2mc=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-bqAmv+2te1foBbCZP6+QwNa+Ej9GVKQRvn\/O1lINe2k=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-8L6pzpycBrKxgs\/3WsBVoR\/7NenUcL+e0i19DvlMog8=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-SozZnCb38JE0AZkWYzjZ0ZSZx5WGRjD2xu0lZYPuoL0=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-TSzg6qsgsxZ162vc0deudnTvJ85ORFBpjYjqJ7LqFSA=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-g1C9Fnh++M4k1mLduCz2yUnf\/70tTCbdZ\/s6bDjsmZM=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-32yXMbcCMbfUq7vtlIPput8uO7SZK8E9m3V8EXMScBc=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-21OaCJJX+k6M+dYEFb5j1eJU+K+Sk6lvYDaRnsKqy8A=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-E1ZVZc8ppcbuan9B4K4NDw+BijA0pjKkIIwlnGerx9g=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-wHCCb7HUqrLXqDMEQwd0GmAIVldcEUoINmckuy9iErc=",
      "url": "_framework\/Plotly.Blazor.dll"
    },
    {
      "hash": "sha256-CETD5tkXtiKEgbXyN\/lp0Ejf6LcHIhgeQIEyow2mhmY=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-kB89OjZ7K125Awmno8q9PMGa7TcUZZxouWr6hQ+S\/zQ=",
      "url": "_framework\/SpaFileReader.dll"
    },
    {
      "hash": "sha256-xRFV1CvfzjFNJSOPvppYsDzXkiY+CQM9H\/ZCZujK8rg=",
      "url": "_framework\/SpaInspector.dll"
    },
    {
      "hash": "sha256-sa3ijvE71zSd7D3zHfSEDGBkAc2WqWZQVr6mMFP4Q58=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-7NJ55BkhIzbEb1zKOUveqkXnoHdTx\/Z4Czl4PdTNhGk=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-q\/1sosDFtqKjhCOLoFr1xh0URpILPPW7mDJHOHGg3AA=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-MaggRxnra29kJiFO3J2sUwgxhyegCxCEhEnzqzxOI+8=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-+kMe054LK0jzG+5X78g4OfkyeTOlHVdlbiRU8mV3GOA=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-2aCSYVrWWG4R85aQ4Y3b8wZ+l0dW+uhW3\/byKRgFIU4=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-yJQemyNDn74r1iII4tcySCGTO2mwncnJKLFDcppkpZ0=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-IaMfHrVb5O+1vq97DcO8wrUcEpAss\/Q51q0BaU+tUEg=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-4RwsB0rfvGeFoXRaP1tZpBGXGlHQH8fq2mXntn33sGI=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-dlR9yasMQrM941neqB+Qo7C4GYoofFaxDurvaDYVPw4=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-63UnV90tOWMNVns7LrFdBJzBHwDcfn+ZNxYRl\/W6EBg=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-n3H+GS8wG8DnUPE+LXhuKqyfTHBTU+2uOuxtxUtNva8=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-ALBSRoGR472hR54vRwJcfLAwL2MAidAhFVQqnw5wRMA=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-mJqm0fs7TcqJY7enZQnYltkB4u\/0SjPfiBkfLn9xT3U=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-PjKgHKadQnQN7NsWZ2eRF4cCCGvDWoaw+FOMqQibLZY=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-lqH3zHVsKkFfV2Ci6z3k3Cmzb32+z5fEh4JfKPtU5eg=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-6tE8piZW53fOFYTSCe5nk6U9YxtCHKJShPxVFllPlZ4=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-ItVdePykvlkTfb0UDyC9l19dbMMYdSWNLfzPFgsG+FM=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-VXrm\/GOkbDsv+QITY0afU6Vladx3kAXIXEFjVGYw4EM=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-GRC9+Eq2Tjv9rx1jXmEwAxznPhj5ypQNWLuYrVnlmac=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-u9yhxL8tcFwy2clToyYzBAJnAEzqr\/HezM1ljXAT4TA=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-czwvjFNG4nHlq4V7HRLUJm8jynVXTzmEKh9vNVMaByQ=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-HQ\/auZN0\/9chwgITGjoXL68Id\/0YHiBXG+63f5zvjMk=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-aUUhSORllrlw6mUXuKFR72wUPfryKu60ogDqZUdBukM=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "3hnU7mcB"
};
